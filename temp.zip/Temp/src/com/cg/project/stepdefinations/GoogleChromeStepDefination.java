package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleChromeStepDefination {

	WebDriver driver;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sakondap\\Desktop\\New folder (3)\\chromedriver.exe" );
	}
	@Given("^User Open Browser$")
	public void user_Open_Browser() throws Throwable {
		driver= new ChromeDriver();
	}

	@When("^User will enter 'www\\.google\\.com' in address bar of browser$")
	public void user_will_enter_www_google_com_in_address_bar_of_browser() throws Throwable {
		driver.get("https://www.google.com");
	}

	@Then("^Google web site Home Page should display$")
	public void google_web_site_Home_Page_should_display() throws Throwable {
		String expectedTitle="Google";
		String actualTitle=driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}
	
	@Given("^User able to enter text in searchBox$")
	public void user_able_to_enter_text_in_searchBox() throws Throwable {
		driver= new ChromeDriver();
		driver.get("https://www.google.com");
	}

	@When("^User will enter 'JDK' in search box$")
	public void user_will_enter_JDK_in_search_box() throws Throwable {
		WebElement searchField = driver.findElement(By.id("lst-ib"));
		 searchField.sendKeys("JDK"); 
		 searchField.submit();
	}

	@Then("^Multipal Links show display for JDK informaton$")
	public void multipal_Links_show_display_for_JDK_informaton() throws Throwable {
		String expectedTitle="JDK - Google Search";
		String actualTitle=driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}

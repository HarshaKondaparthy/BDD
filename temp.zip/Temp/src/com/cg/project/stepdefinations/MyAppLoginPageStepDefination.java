package com.cg.project.stepdefinations;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.LoginPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MyAppLoginPageStepDefination {
	
	private WebDriver driver;
	private LoginPage loginPage;
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\sakondap\\Desktop\\New folder (3)\\chromedriver.exe" );
	}
	/*@Given("^User is on MyApp Login Page$")
	public void user_is_on_MyApp_Login_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("https://github.com/login");
		loginPage=new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}

	@When("^User Click on 'Sigin In' without entring 'username'$")
	public void user_Click_on_Sigin_In_without_entring_username() throws Throwable {
		loginPage.setUsername("");
		loginPage.clickSignIn();
		
	}

	@Then("^'Plz Enter UserName' message should display$")
	public void plz_Enter_UserName_message_should_display() throws Throwable {
		String expectedMessage="Plz Enter UserName";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Click on 'Sigin In' without entring 'password'$")
	public void user_Click_on_Sigin_In_without_entring_password() throws Throwable {
	   driver.switchTo().alert().dismiss();
		loginPage.setUsername("harsha96180@gmail.com");
		loginPage.setPassword("");
		loginPage.clickSignIn();
	}

	@Then("^'Plz Enter Password' message should display$")
	public void plz_Enter_Password_message_should_display() throws Throwable {
		String expectedMessage="Plz Enter Password";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^User Click on 'Sigin In'  with invalid credentials$")
	public void user_Click_on_Sigin_In_with_invalid_credentials() throws Throwable {
		 
			loginPage.setUsername("SaSaSa");
			loginPage.setPassword("ABC");
			loginPage.clickSignIn();
	}

	@Then("^'UserName or Password is incorrect' message should display$")
	public void username_or_Password_is_incorrect_message_should_display() throws Throwable {
		String expectedMessage="UserName or Password is incorrect";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^User Click on 'Sigin In'  with Valid credentials$")
	public void user_Click_on_Sigin_In_with_Valid_credentials() throws Throwable {
			loginPage.setUsername("harsha96180@gmail.com");
			loginPage.setPassword("Venkatesh@96180");
			loginPage.clickSignIn();
	}

	@Then("^'Welcome UserName ' message should display and Welcome Page should load with title 'Welcome To MyApp'$")
	public void welcome_UserName_message_should_display_and_Welcome_Page_should_load_with_title_Welcome_To_MyApp() throws Throwable {
		String expectedMessage="Welcome harsha";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		 driver.switchTo().alert().dismiss();
		 String expectedPageTitle="Welcome To MyApp";
		 String actualPageTitle=driver.getTitle();
		 Assert.assertEquals(expectedPageTitle, actualPageTitle);
	}*/
	@Given("^Signup$")
	public void Signup() throws Throwable {
		driver = new ChromeDriver();
		driver.get("https://www.amazon.in/ap/register?showRememberMe=true&openid.pape.max_auth_age=0&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&pageId=inflex&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26ref_%3Dnav_custrec_newcust&prevRID=BPKMWY2XS44CZ118VSV0&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&prepopulatedLoginId=&failedSignInCount=0&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
		loginPage=new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}
		
		 @When("^SuccessSignup$")
			public void SuccessSignup() throws Throwable {
				 
					loginPage.setUsername("HimanshuSrivastava");
					loginPage.setphoneno("9821235404");
					loginPage.setEmailname("SaSaSa15151@gmail.com");
					loginPage.setPassword("ABC@abc$1234");
					loginPage.clickSignUp();
			}

			@Then("^successRegistration$")
			public void successRegistration() throws Throwable {
				String expectedMessage="successRegistration";
				String actualMessage=driver.switchTo().alert().getText();
				Assert.assertEquals(expectedMessage, actualMessage);
				driver.close();
		
	
		 
	
}}

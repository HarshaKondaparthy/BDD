package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPage {

	@FindBy(how=How.NAME,name="customerName")
	private WebElement username;
	
	@FindBy(how=How.NAME,name="secondaryLoginClaim")
	private WebElement Emailname;
	
	@FindBy(how=How.NAME,name="password")
	private WebElement password;
	
	@FindBy(how=How.NAME,name="email")
	private WebElement phoneno ;
	
	@FindBy(how=How.NAME,name="a-button")
	private WebElement siginInButton;
	
	@FindBy(how=How.ID,id="continue")
	private WebElement siginUpButton;

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	public String getphoneno() {
		return phoneno.getAttribute("value");
	}

	public void setphoneno(String phoneno) {
		this.phoneno.sendKeys(phoneno);
	}

	public void clickSignIn() {
		this.siginInButton.click();
	}

	public String getEmailname() {
		return Emailname.getAttribute("value");
	}
	public void setEmailname(String Emailname) {
		this.Emailname.sendKeys(Emailname);
		
	}
	public void clickSignUp() {
		this.siginUpButton.click();
	}


}
